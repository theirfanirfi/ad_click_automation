# Make this False to disable proxy.
use_proxy = True

PROXY_HOST = 'p.webshare.io'  # rotating proxy or host
PROXY_PORT = 80  # port
PROXY_USER = 'tvfdriua-rotate'  # username
PROXY_PASS = '2ky8chtsoxqf'  # password

# Number of search results to perform per proxy
searches_per_proxy = 1
